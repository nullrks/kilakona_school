<?php

if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

$config['envato_market_purchase_code'] = '';
$config['envato_market_username'] = '';
$config['SSLK'] = '';
$config['app_ver'] = 0;
